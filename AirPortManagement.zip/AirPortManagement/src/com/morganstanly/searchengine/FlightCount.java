package com.morganstanly.searchengine;

import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.morganstanly.appdata.SampleDataset;
import com.morganstanly.util.DateParser;

public class FlightCount {

	private Map<String, List<List<Date>>> dataMap;
	static Logger logger = Logger.getLogger(FlightCount.class.getName());
	private static FlightCount flightCountInstance=null;  
	private FlightCount(){
		dataMap=SampleDataset.getInstanceOfSampleDataset().getDataMap();
	}
	
	public static FlightCount getInstanceOfFlightCount(){
		
		if(null==flightCountInstance)
		{
			flightCountInstance=new FlightCount();
		}
		
		return flightCountInstance;
	}
	
	public String getFlightCountOnAirport(Date date){
		logger.info("Class:FlightCount method:getFlightCountOnAirport()");
		String currentDate=DateParser.getInstanceOfDateParser().getDate(date);
		
		List<List<Date>> schedule=dataMap.get(currentDate);
		if(schedule==null)
		{
			return "Warning! Date is out of range, kindly enter valid date";			 
		}
		List<Date> arrivalTime=schedule.get(0);	
		List<Date> departureTime=schedule.get(1);	
		int count=0;
		for(int index=0;index<arrivalTime.size();index++)
		{
			if(arrivalTime.get(index).compareTo(date)<=0 && departureTime.get(index).compareTo(date)>=0)
			{
				count++;
			}
		}		
		return count+"";
	}
	
	
}

package com.morganstanly.searchengine;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.morganstanly.appdata.SampleDataset;
import com.morganstanly.util.DateParser;

public class BusiestTime {

	private Map<String, List<List<Date>>> dataMap;
	static Logger logger = Logger.getLogger(BusiestTime.class.getName());
	private static BusiestTime busiestTimeInstance;
	private BusiestTime(){
		dataMap=SampleDataset.getInstanceOfSampleDataset().getDataMap();
	}
	
	public static BusiestTime getInstanceOfBusiestTime(){
		
		if(null==busiestTimeInstance)
		{
			busiestTimeInstance=new BusiestTime();
		}
		return busiestTimeInstance;
	} 
	
	public String getBusiestTime(Date date){
		
		logger.info("Class:FlightCount method:getFlightCountOnAirport()");
		String currentDate=DateParser.getInstanceOfDateParser().getDate(date);
		List<Date> busiestTime=new ArrayList<Date>();
		String busiestHour="";
		List<List<Date>> schedule=dataMap.get(currentDate);
		if(schedule==null)
		{
			return "Warning! Date is out of range, kindly enter valid date";
		}
		
		List<Date> arrivalTime=schedule.get(0);	
		List<Date> departureTime=schedule.get(1);	
				
		Collections.sort(arrivalTime);
		Collections.sort(departureTime);
		
		int count=0;
		int maxCount=0;
		Date time = null;
			for(int departureIndex=0;departureIndex<departureTime.size();departureIndex++)
			{
				count=1;
				for(int arrivalIndex=departureIndex+1;arrivalIndex<arrivalTime.size();arrivalIndex++)
				{
					if(arrivalTime.get(arrivalIndex).compareTo(departureTime.get(departureIndex))<=0)
					{
						
						count++;
					}	
					
					if(count>maxCount)
					{
						maxCount=count;	
						time=arrivalTime.get(arrivalIndex);
						
					}
								
				}
				
			}
					
		   busiestHour=DateParser.getInstanceOfDateParser().getHour(time);	
		   return busiestHour;
	}
	
}

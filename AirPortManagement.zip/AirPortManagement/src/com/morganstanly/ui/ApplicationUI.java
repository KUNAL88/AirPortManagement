package com.morganstanly.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.Date;

import org.apache.log4j.Logger;

import com.morganstanly.app.AirPortManagementDemo;
import com.morganstanly.searchengine.BusiestTime;
import com.morganstanly.searchengine.FlightCount;
import com.morganstanly.util.DateParser;

public class ApplicationUI {

	private static ApplicationUI appInstance=null;
	private static BufferedReader reader=null;
	static Logger logger = Logger.getLogger(ApplicationUI.class.getName());
	private ApplicationUI(){
		reader=new BufferedReader(new InputStreamReader(System.in));
	}
	
	public static ApplicationUI getInstanceOfAppUI(){
		
		if(null==appInstance)
		{
			appInstance=new ApplicationUI();
		}		
		return appInstance;
	}	
	public void start(){
		logger.info("Class:ApplicationUI method:start()");
		int option=0;
		Date dateInstance=null;
		while(true)
		{
			System.out.println("Press .....");
			System.out.println("1. Find Busiest Time on Airport");
			System.out.println("2. Find Number of Flights Available on Airport ");
			System.out.println("3. Exit");
			try {
				option=Integer.parseInt(reader.readLine());
			} catch (NumberFormatException e) {
				logger.error("Error Parsing date "+e);
			} catch (IOException e) {
				logger.error("IOException reading date "+e);
			}
			switch(option)
			{
			case 1:dateInstance=getInputBusiestTime();
					System.out.println(BusiestTime.getInstanceOfBusiestTime().getBusiestTime(dateInstance));
				break;
			case 2:dateInstance= getInputFlightCount();
					System.out.println(FlightCount.getInstanceOfFlightCount().getFlightCountOnAirport(dateInstance));
				break;
			case 3:System.exit(0);
				break;
			default:System.out.println("Invalid Input");
			}//end switch-case
		}//end while
	}//end 
	
	private static Date  getInputBusiestTime(){
		String date=null;
		Date dateInstance=null;
		System.out.println("Please Enter Date in (yyyy-mm-dd) format...");
		try {
			date=reader.readLine();
		} catch (IOException e) {
			logger.error("IOException while reading Parsing date "+e);
		}		
		try {
			dateInstance=DateParser.getInstanceOfDateParser().getYearDateFormatter().parse(date);
		} catch (ParseException e) {
			logger.error("Error Parsing date "+e);
			System.out.println("Wrong Input .....");
			getInputBusiestTime();
		}		
		return dateInstance;
	}
	
   private static Date getInputFlightCount(){
	   String date=null;
	   Date dateInstace=null;
	   System.out.println("Please Enter Date in (yyyy-mm-dd hh:mm) format");
	   try {
		date=reader.readLine();
	} catch (IOException e) {
		logger.error("IOException while reading Parsing date "+e);
	}
		try {
			dateInstace=DateParser.getInstanceOfDateParser().getHourDateFormatter().parse(date);
			
		} catch (ParseException e) {
			logger.error("Error Parsing date "+e);
			getInputFlightCount();
		}		
		return dateInstace;
   }	
}

package com.morganstanly.appdata;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.morganstanly.util.DateParser;

public class SampleDataset {

	private static SampleDataset datasetInstance=null;
	private List<Date> arrivalTime1=new ArrayList<Date>();
	private List<Date> departureTime1=new ArrayList<Date>();
	
	private List<Date> arrivalTime2=new ArrayList<Date>();
	private List<Date> departureTime2=new ArrayList<Date>();
	
	private List<Date> arrivalTime3=new ArrayList<Date>();
	private List<Date> departureTime3=new ArrayList<Date>();
	private SampleDataset(){
		
	}
	
	public static SampleDataset getInstanceOfSampleDataset(){
		
		if(null==datasetInstance)
		{
			datasetInstance=new SampleDataset();
		}		
		return datasetInstance;
	}
	
  private List<Date> loadArrivalData1(){
		
	     SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	
	
		try {
			arrivalTime1.add(formater.parse("2014-04-15 10:25"));
			arrivalTime1.add(formater.parse("2014-04-15 11:30"));
			arrivalTime1.add(formater.parse("2014-04-15 11:36"));
			arrivalTime1.add(formater.parse("2014-04-15 11:40"));
			arrivalTime1.add(formater.parse("2014-04-15 11:41"));
			arrivalTime1.add(formater.parse("2014-04-15 13:00"));		
			arrivalTime1.add(formater.parse("2014-04-15 15:40"));
			arrivalTime1.add(formater.parse("2014-04-15 17:30"));
			arrivalTime1.add(formater.parse("2014-04-15 18:10"));
			arrivalTime1.add(formater.parse("2014-04-15 19:20"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return arrivalTime1;
	}

  private List<Date> loadDepartureData1(){
	
	SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	
	try {
		departureTime1.add(formater.parse("2014-04-15 10:50"));
		departureTime1.add(formater.parse("2014-04-15 11:50"));				
		departureTime1.add(formater.parse("2014-04-15 11:46"));		
		departureTime1.add(formater.parse("2014-04-15 11:45"));		
		departureTime1.add(formater.parse("2014-04-15 11:45"));
		departureTime1.add(formater.parse("2014-04-15 13:10"));
		departureTime1.add(formater.parse("2014-04-15 15:50"));
		departureTime1.add(formater.parse("2014-04-15 17:40"));
		departureTime1.add(formater.parse("2014-04-15 18:20"));
		departureTime1.add(formater.parse("2014-04-15 19:30"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}    
	return departureTime1;
}

  private List<Date> loadArrivalData2(){
		
	     SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	
	
		try {
			arrivalTime2.add(formater.parse("2014-04-20 00:00"));
			arrivalTime2.add(formater.parse("2014-04-20 00:00"));
			arrivalTime2.add(formater.parse("2014-04-20 00:06"));
			arrivalTime2.add(formater.parse("2014-04-20 00:09"));
			arrivalTime2.add(formater.parse("2014-04-20 11:41"));
			arrivalTime2.add(formater.parse("2014-04-20 13:00"));		
			arrivalTime2.add(formater.parse("2014-04-20 15:40"));
			arrivalTime2.add(formater.parse("2014-04-20 17:30"));
			arrivalTime2.add(formater.parse("2014-04-20 18:10"));
			arrivalTime2.add(formater.parse("2014-04-20 19:20"));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return arrivalTime2;
	}

private List<Date> loadDepartureData2(){
	
	SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	
	try {
		departureTime2.add(formater.parse("2014-04-20 00:10"));
		departureTime2.add(formater.parse("2014-04-20 00:11"));				
		departureTime2.add(formater.parse("2014-04-20 00:16"));		
		departureTime2.add(formater.parse("2014-04-20 00:15"));		
		departureTime2.add(formater.parse("2014-04-20 11:45"));
		departureTime2.add(formater.parse("2014-04-20 13:10"));
		departureTime2.add(formater.parse("2014-04-20 15:50"));
		departureTime2.add(formater.parse("2014-04-20 17:40"));
		departureTime2.add(formater.parse("2014-04-20 18:20"));
		departureTime2.add(formater.parse("2014-04-20 19:30"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}    
	return departureTime2;
}
  
private List<Date> loadArrivalData3(){
	
    SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	

	try {
		arrivalTime3.add(formater.parse("2014-04-30 01:00"));
		arrivalTime3.add(formater.parse("2014-04-30 02:00"));
		arrivalTime3.add(formater.parse("2014-04-30 03:00"));
		arrivalTime3.add(formater.parse("2014-04-30 04:00"));
		arrivalTime3.add(formater.parse("2014-04-30 11:41"));
		arrivalTime3.add(formater.parse("2014-04-30 23:00"));		
		arrivalTime3.add(formater.parse("2014-04-30 23:40"));
		arrivalTime3.add(formater.parse("2014-04-30 23:30"));
		arrivalTime3.add(formater.parse("2014-04-30 23:10"));
		arrivalTime3.add(formater.parse("2014-04-30 23:20"));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return arrivalTime3;
}

private List<Date> loadDepartureData3(){

SimpleDateFormat formater=DateParser.getInstanceOfDateParser().getHourDateFormatter();	
try {
	departureTime3.add(formater.parse("2014-04-30 01:10"));
	departureTime3.add(formater.parse("2014-04-30 02:11"));				
	departureTime3.add(formater.parse("2014-04-30 03:16"));		
	departureTime3.add(formater.parse("2014-04-30 04:15"));		
	departureTime3.add(formater.parse("2014-04-30 11:45"));
	departureTime3.add(formater.parse("2014-04-30 23:59"));
	departureTime3.add(formater.parse("2014-04-30 23:59"));
	departureTime3.add(formater.parse("2014-04-30 23:59"));
	departureTime3.add(formater.parse("2014-04-30 23:59"));
	departureTime3.add(formater.parse("2014-04-30 23:59"));
} catch (ParseException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}    
return departureTime3;
}


 
public Map<String, List<List<Date>>> getDataMap(){
	  
	  List<List<Date>> schedule1=new ArrayList<List<Date>>();
	  List<List<Date>> schedule2=new ArrayList<List<Date>>();
	  List<List<Date>> schedule3=new ArrayList<List<Date>>();
	  
	  schedule1.add(loadArrivalData1());		schedule1.add(loadDepartureData1());	
	  schedule2.add(loadArrivalData2());		schedule2.add(loadDepartureData2());
	  schedule3.add(loadArrivalData3());		schedule3.add(loadDepartureData3());
	  Map<String, List<List<Date>>> dataMap=new HashMap<String, List<List<Date>>>();
	  dataMap.put("2014-04-15", schedule1);
	  dataMap.put("2014-04-20", schedule2);
	  dataMap.put("2014-04-30", schedule3);
	  return dataMap;
  }


}

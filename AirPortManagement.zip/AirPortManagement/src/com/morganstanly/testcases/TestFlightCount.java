package com.morganstanly.testcases;

import static org.junit.Assert.assertEquals;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;

import com.morganstanly.searchengine.FlightCount;
import com.morganstanly.util.DateParser;

public class TestFlightCount {

	static SimpleDateFormat format=null;
	FlightCount flightCount=FlightCount.getInstanceOfFlightCount();
	@BeforeClass
	public static void getSimpleDateFormatterInstance()
	{
		format=DateParser.getInstanceOfDateParser().getHourDateFormatter();
	}
	
	@Test
	public void testBusiestTimeStartOfDay() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-20 00:09");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=flightCount.getFlightCountOnAirport(date);
	     assertEquals("4", result);
	   }
	
	@Test
	public void testBusiestTimeEndOfDay() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-30 23:55");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=flightCount.getFlightCountOnAirport(date);
	     assertEquals("5", result);
	   }
	
	
	
	
	@Test
	public void testBusiestTime() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-15 11:41");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=flightCount.getFlightCountOnAirport(date);
	     assertEquals("4", result);
	   }
	
	
	@Test
	public void testBusiestTimeForOutsideDate(){
		
		Date date = null;
		 String result="";
		try {
			date = format.parse("2013-04-15 11:21");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=flightCount.getFlightCountOnAirport(date);
	     assertEquals("Warning! Date is out of range, kindly enter valid date", result);
	}
	
}

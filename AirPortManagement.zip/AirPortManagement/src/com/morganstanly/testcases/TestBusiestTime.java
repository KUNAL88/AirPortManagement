package com.morganstanly.testcases;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.BeforeClass;
import org.junit.Test;

import com.morganstanly.searchengine.BusiestTime;
import com.morganstanly.util.DateParser;

public class TestBusiestTime {
	
	BusiestTime busiestTime=BusiestTime.getInstanceOfBusiestTime().getInstanceOfBusiestTime();	
	static SimpleDateFormat format=null;
	@BeforeClass
	public static void getSimpleDateFormatterInstance()
	{
		format=DateParser.getInstanceOfDateParser().getYearDateFormatter();
	}
	
	@Test
	public void testBusiestTimeStartOfDay() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-20");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=busiestTime.getBusiestTime(date);
	     assertEquals("00:09", result);
	   }
	
	@Test
	public void testBusiestTimeEndOfDay() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-30");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=busiestTime.getBusiestTime(date);
	     assertEquals("23:40", result);
	   }
	
	
	
	
	@Test
	public void testBusiestTime() {
		 Date date = null;
		 String result="";
		try {
			date = format.parse("2014-04-15");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=busiestTime.getBusiestTime(date);
	     assertEquals("11:41", result);
	   }
	
	
	@Test
	public void testBusiestTimeForOutsideDate(){
		
		Date date = null;
		 String result="";
		try {
			date = format.parse("2013-04-15");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     result=busiestTime.getBusiestTime(date);
	     assertEquals("Warning! Date is out of range, kindly enter valid date", result);
	}
		
}

package com.morganstanly.util;

import java.net.DatagramPacket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.morganstanly.ui.ApplicationUI;

public class DateParser {

	private SimpleDateFormat hourDateFormatter=null;
	private SimpleDateFormat yearDateFormatter=null;
	private SimpleDateFormat hourMinuteDateFormatter=null;
	static Logger logger = Logger.getLogger(ApplicationUI.class.getName());
	
	private static DateParser dateParserInstance=null;
	
	private DateParser(){
		hourDateFormatter=new SimpleDateFormat("yyyy-MM-dd hh:mm");
		yearDateFormatter=new SimpleDateFormat("yyyy-MM-dd");
		hourMinuteDateFormatter=new SimpleDateFormat("hh:mm");
	}
	
	public static DateParser getInstanceOfDateParser(){
		
		if(null==dateParserInstance){
			dateParserInstance=new DateParser();
		}
		return dateParserInstance;
	}
	
	
	public SimpleDateFormat getHourDateFormatter() {
		return hourDateFormatter;
	}

	public SimpleDateFormat getYearDateFormatter() {
		return yearDateFormatter;
	}
	
	public SimpleDateFormat getHourMinuteDateFormatter() {
		return hourMinuteDateFormatter;
	}

	public String getDate(Date dateInstance){
		
		DateFormat dateformat=new SimpleDateFormat("yyyy-MM-dd");
		return dateformat.format(dateInstance);
	}
	
	public String getHour(Date dateInstance){
		DateFormat dateformat=new SimpleDateFormat("HH:mm");
		
		return dateformat.format(dateInstance);
	}

}

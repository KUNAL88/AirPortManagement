package com.morganstanly.app;

import org.apache.log4j.Logger;

import com.morganstanly.ui.ApplicationUI;


public class AirPortManagementDemo {

	static Logger logger = Logger.getLogger(AirPortManagementDemo.class.getName());
	public static void main(String[] args) {
		// TODO Auto-generated method stub	
		logger.info("Class:AirPortManagementDemo Method:main()");
		ApplicationUI.getInstanceOfAppUI().start();		
	}

}
